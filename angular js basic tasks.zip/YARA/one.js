const number = prompt("Enter a number");

if (number%2==0){
    document.write("number is even");

}
else{
    document.write("number is odd");
}