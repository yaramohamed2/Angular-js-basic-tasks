var sum=0
let i 
for( i=1;i<=10;i++){
sum+=i
}
document.write('the sum = '+sum)