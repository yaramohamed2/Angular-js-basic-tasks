let i
for( i =0;i<=5;i++){
    let j
    for( j=0;j<=i;j++){
        document.write('*');
    }
    document.write('<br>')
}