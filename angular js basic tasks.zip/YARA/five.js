let x=parseInt(prompt('Enter Number 1 ='))
let y=parseInt(prompt('Enter Number 2 ='))
let sum=x+y
if(x==50 || y==50 ||sum==50)
{document.write('True')}
else{ document.write('False')}