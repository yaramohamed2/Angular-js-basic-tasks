const number = parseInt(prompt("Enter a number: "));


if (number > 0) {
    document.write("The number is positive");
}


else if (number == 0) {
    document.write("The number is zero");
}

else {
    document.write("The number is negative");
}