var r, d, c, a;
    
    // r = radius
    // d = diameter
    // c = circumference
    // a = area
    
    /* Calculation of diameter, circumference, and area */
    
    r = 10;
    d = 2 * 10;
    c = 2 * 3.14 * 10;
    a = 3.14 * (10 * 10);
    
    document.write("Diameter = " + d + " units<br />");
    document.write("Circumference = " + c + " units<br />");
    document.write("Area = " + a + " sq. units");