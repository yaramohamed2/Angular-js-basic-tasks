var num 

num = prompt('Enter the number')


if (num % 3 == 0)
	document.write('Multiple of 3')
 else if(num% 5 ==0)
  document.write(' multiple of 5')
  else
  document.write('not a multiple of 3 or 5')

